import java.util.Scanner;

public class MovieDriverTask2 {

	public static void main(String[] args) {
		
		boolean yesNo = true;
		String movieName, movieRating, choice;
		int ticketsSold;
		
		Scanner scanner = new Scanner(System.in);
		Movie movie = new Movie();
		
		
		do {
			
				
			System.out.println("Enter the name of a movie: ");
			movieName = scanner.nextLine();
			movie.setTitle(movieName);
				
			System.out.println("Enter the rating of the movie: ");
			movieRating = scanner.nextLine();
			movie.setRating(movieRating);

			System.out.println("Enter the number of tickets sold for this movie: ");
			ticketsSold = scanner.nextInt();
			movie.setSoldTickets(ticketsSold);
			scanner.nextLine();
				
			System.out.println(movie.toString());
			
			
			do {
				System.out.println("Do you want to enter another? (y or n)");
				choice = scanner.nextLine();
				if (choice.equalsIgnoreCase("y")) {
					
					continue;
				}  
				
				if (choice.equalsIgnoreCase("n")) {
					yesNo = false;
					break;
				} 
				
			} while (!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"));
			
			
			
			
		} while (yesNo == true);
		
		System.out.println("Goodbye!");
		
	}

}
