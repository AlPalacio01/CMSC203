import java.util.Scanner;

public class MovieDriverTask1 {

	public static void main(String[] args) {
		
		String movieName, movieRating;
		int ticketsSold;
		
		Scanner scanner = new Scanner(System.in);
		Movie movie = new Movie();
		
		System.out.println("Enter the name of a movie: ");
		movieName = scanner.nextLine();
		movie.setTitle(movieName);
		
		System.out.println("Enter the rating of the movie: ");
		movieRating = scanner.nextLine();
		movie.setRating(movieRating);

		System.out.println("Enter the number of tickets sold for this movie: ");
		ticketsSold = scanner.nextInt();
		movie.setSoldTickets(ticketsSold);
		scanner.nextLine();
		
		System.out.println(movie.toString());
		System.out.println("Goodbye!");
		
	}

}
